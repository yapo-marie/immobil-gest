from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.chat import ChatMessageCreate, ChatMessageRecord, ConversationCreate, ConversationRecord

router = APIRouter(prefix="/api/chat", tags=["chat"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def map_records(snapshot: Optional[dict], model):
  if not isinstance(snapshot, dict):
    return []
  results = []
  for record_id, raw in snapshot.items():
    data = raw or {}
    try:
      results.append(model(id=record_id, **data))
    except Exception:
      continue
  return results


@router.post("/conversations", response_model=ConversationRecord, status_code=status.HTTP_201_CREATED)
async def create_conversation(
  payload: ConversationCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "chatConversations", method="POST", body=body)
  conv_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return ConversationRecord.model_validate({**body, "id": conv_id})


@router.get("/conversations", response_model=list[ConversationRecord])
async def list_conversations(
  request: Request,
  ownerId: Optional[str] = None,
  tenantId: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "chatConversations")
  conversations = map_records(snapshot, ConversationRecord)
  if ownerId:
    conversations = [c for c in conversations if c.ownerId == ownerId]
  if tenantId:
    conversations = [c for c in conversations if c.tenantId == tenantId]
  conversations.sort(key=lambda c: c.createdAt, reverse=True)
  return conversations


@router.post("/messages", response_model=ChatMessageRecord, status_code=status.HTTP_201_CREATED)
async def send_message(
  payload: ChatMessageCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if not payload.content.strip():
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Message vide.")
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "chatMessages", method="POST", body=body)
  message_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return ChatMessageRecord.model_validate({**body, "id": message_id})


@router.get("/messages", response_model=list[ChatMessageRecord])
async def list_messages(
  request: Request,
  conversationId: str,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "chatMessages")
  messages = map_records(snapshot, ChatMessageRecord)
  messages = [m for m in messages if m.conversationId == conversationId]
  messages.sort(key=lambda m: m.createdAt)
  return messages
