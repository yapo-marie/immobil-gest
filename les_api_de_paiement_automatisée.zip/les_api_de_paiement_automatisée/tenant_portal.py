from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.document import DocumentRecord
from ..models.maintenance import TicketRecord
from ..models.payment import PaymentHistoryItem
from ..services.payment_service import list_checkout_sessions
from . import payments as payments_router

router = APIRouter(prefix="/api/tenant-portal", tags=["tenant-portal"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def map_documents(snapshot: Optional[dict]) -> list[DocumentRecord]:
  if not isinstance(snapshot, dict):
    return []
  docs = []
  for doc_id, raw in snapshot.items():
    record = raw or {}
    try:
      docs.append(
        DocumentRecord(
          id=doc_id,
          type=record.get("type") or "document",
          title=record.get("title") or "Document",
          ownerId=record.get("ownerId"),
          tenantId=record.get("tenantId"),
          tenantName=record.get("tenantName"),
          propertyId=record.get("propertyId"),
          propertyName=record.get("propertyName"),
          amount=float(record.get("amount")) if record.get("amount") is not None else None,
          currency=record.get("currency") or "XOF",
          period=record.get("period"),
          version=int(record.get("version") or 1),
          fileName=record.get("fileName"),
          archivedAt=record.get("archivedAt"),
          createdAt=record.get("createdAt") or "",
        )
      )
    except Exception:
      continue
  return docs


def map_tickets(snapshot: Optional[dict]) -> list[TicketRecord]:
  if not isinstance(snapshot, dict):
    return []
  tickets = []
  for ticket_id, raw in snapshot.items():
    record = raw or {}
    try:
      tickets.append(TicketRecord(id=ticket_id, **record))
    except Exception:
      continue
  return tickets


@router.get("/overview", response_model=dict)
async def tenant_overview(
  request: Request,
  tenantId: Optional[str] = None,
  tenantEmail: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  if not tenantId and not tenantEmail:
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="tenantId ou tenantEmail requis.")

  client = get_client(request)

  # Documents
  _, doc_snapshot = await firebase_request(client, settings, "documents")
  documents = map_documents(doc_snapshot)
  if tenantId:
    documents = [d for d in documents if d.tenantId == tenantId]
  if tenantEmail:
    # Optionnel si tenantEmail stocké; sinon on garde tenantId.
    documents = [d for d in documents if getattr(d, "tenantEmail", None) == tenantEmail]

  # Tickets
  _, ticket_snapshot = await firebase_request(client, settings, "tickets")
  tickets = map_tickets(ticket_snapshot)
  if tenantId:
    tickets = [t for t in tickets if t.tenantId == tenantId]

  # Payments history via Stripe
  stripe = payments_router.get_stripe(request)
  sessions = await list_checkout_sessions(stripe)
  payments: list[PaymentHistoryItem] = []
  for session in sessions.get("data", []):
    metadata = session.get("metadata") or {}
    if tenantId and metadata.get("tenantId") != tenantId:
      continue
    if tenantEmail and metadata.get("tenantEmail", "").lower() != tenantEmail.lower():
      continue
    payment_intent = session.get("payment_intent") if isinstance(session.get("payment_intent"), dict) else None
    charge = (payment_intent or {}).get("charges", {}).get("data", [None])[0] or {}
    receipt_url = charge.get("receipt_url")
    paid_at = (
      datetime.utcfromtimestamp(charge.get("created")).isoformat()
      if session.get("payment_status") == "paid" and charge.get("created")
      else None
    )
    payments.append(
      PaymentHistoryItem(
        id=session.get("id"),
        amount=(session.get("amount_total") or 0) / 100 if session.get("amount_total") else None,
        currency=session.get("currency") or "xof",
        paymentStatus=session.get("payment_status"),
        sessionStatus=session.get("status"),
        tenantName=metadata.get("tenantName"),
        tenantEmail=metadata.get("tenantEmail") or (session.get("customer_details") or {}).get("email"),
        tenantId=metadata.get("tenantId"),
        propertyName=metadata.get("propertyName"),
        propertyId=metadata.get("propertyId"),
        ownerId=metadata.get("ownerId"),
        dueDate=metadata.get("dueDate"),
        paymentMonths=int(metadata.get("paymentMonths")) if metadata.get("paymentMonths") else None,
        createdAt=datetime.utcfromtimestamp(session.get("created")).isoformat(),
        paidAt=paid_at,
        receiptUrl=receipt_url,
      )
    )

  payments.sort(key=lambda p: p.createdAt, reverse=True)
  return {
    "documents": [d.model_dump() for d in documents],
    "tickets": [t.model_dump() for t in tickets],
    "payments": [p.model_dump() for p in payments],
  }
