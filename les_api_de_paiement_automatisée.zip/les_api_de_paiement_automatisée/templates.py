from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.template import TemplateCreate, TemplateRecord

router = APIRouter(prefix="/api/templates", tags=["templates"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def map_records(snapshot: Optional[dict], model):
  if not isinstance(snapshot, dict):
    return []
  results = []
  for record_id, raw in snapshot.items():
    data = raw or {}
    try:
      results.append(model(id=record_id, **data))
    except Exception:
      continue
  return results


@router.post("", response_model=TemplateRecord, status_code=status.HTTP_201_CREATED)
async def create_template(
  payload: TemplateCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if not payload.body.strip():
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Contenu requis.")
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "messageTemplates", method="POST", body=body)
  template_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return TemplateRecord.model_validate({**body, "id": template_id})


@router.get("", response_model=list[TemplateRecord])
async def list_templates(
  request: Request,
  ownerId: Optional[str] = None,
  channel: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "messageTemplates")
  templates = map_records(snapshot, TemplateRecord)
  if ownerId:
    templates = [t for t in templates if t.ownerId == ownerId]
  if channel:
    templates = [t for t in templates if t.channel == channel]
  templates.sort(key=lambda t: t.createdAt, reverse=True)
  return templates
