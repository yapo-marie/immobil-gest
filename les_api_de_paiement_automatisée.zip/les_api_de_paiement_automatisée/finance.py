from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.finance import ChargeCreate, ChargeRecord, ExpenseCreate, ExpenseRecord, FinanceSummary

router = APIRouter(prefix="/api/finance", tags=["finance"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def map_charge_snapshot(snapshot: Optional[dict]) -> list[ChargeRecord]:
  if not isinstance(snapshot, dict):
    return []
  results: list[ChargeRecord] = []
  for charge_id, raw in snapshot.items():
    record = raw or {}
    try:
      results.append(
        ChargeRecord(
          id=charge_id,
          ownerId=record.get("ownerId"),
          propertyId=record.get("propertyId"),
          propertyName=record.get("propertyName"),
          tenantId=record.get("tenantId"),
          tenantName=record.get("tenantName"),
          label=record.get("label"),
          amount=float(record.get("amount") or 0),
          currency=record.get("currency") or "XOF",
          period=record.get("period"),
          category=record.get("category") or "provision",
          createdAt=record.get("createdAt") or "",
        )
      )
    except Exception:
      continue
  return results


def map_expense_snapshot(snapshot: Optional[dict]) -> list[ExpenseRecord]:
  if not isinstance(snapshot, dict):
    return []
  results: list[ExpenseRecord] = []
  for expense_id, raw in snapshot.items():
    record = raw or {}
    try:
      results.append(
        ExpenseRecord(
          id=expense_id,
          ownerId=record.get("ownerId"),
          propertyId=record.get("propertyId"),
          propertyName=record.get("propertyName"),
          vendor=record.get("vendor"),
          label=record.get("label"),
          amount=float(record.get("amount") or 0),
          currency=record.get("currency") or "XOF",
          date=record.get("date"),
          category=record.get("category") or "maintenance",
          notes=record.get("notes"),
          createdAt=record.get("createdAt") or "",
        )
      )
    except Exception:
      continue
  return results


@router.post("/charges", response_model=ChargeRecord, status_code=status.HTTP_201_CREATED)
async def create_charge(
  payload: ChargeCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if payload.amount <= 0:
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Montant de charge invalide.")
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "charges", method="POST", body=body)
  charge_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return ChargeRecord.model_validate({**body, "id": charge_id})


@router.get("/charges", response_model=list[ChargeRecord])
async def list_charges(
  request: Request,
  ownerId: Optional[str] = None,
  propertyId: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "charges")
  charges = map_charge_snapshot(snapshot)
  if ownerId:
    charges = [c for c in charges if c.ownerId == ownerId]
  if propertyId:
    charges = [c for c in charges if c.propertyId == propertyId]
  charges.sort(key=lambda c: c.createdAt, reverse=True)
  return charges


@router.post("/expenses", response_model=ExpenseRecord, status_code=status.HTTP_201_CREATED)
async def create_expense(
  payload: ExpenseCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if payload.amount <= 0:
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Montant de dépense invalide.")
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "expenses", method="POST", body=body)
  expense_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return ExpenseRecord.model_validate({**body, "id": expense_id})


@router.get("/expenses", response_model=list[ExpenseRecord])
async def list_expenses(
  request: Request,
  ownerId: Optional[str] = None,
  propertyId: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "expenses")
  expenses = map_expense_snapshot(snapshot)
  if ownerId:
    expenses = [e for e in expenses if e.ownerId == ownerId]
  if propertyId:
    expenses = [e for e in expenses if e.propertyId == propertyId]
  expenses.sort(key=lambda e: e.date or "", reverse=True)
  return expenses


@router.get("/summary", response_model=FinanceSummary)
async def finance_summary(
  request: Request,
  ownerId: str,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, charge_snapshot = await firebase_request(client, settings, "charges")
  _, expense_snapshot = await firebase_request(client, settings, "expenses")
  charges = [c for c in map_charge_snapshot(charge_snapshot) if c.ownerId == ownerId]
  expenses = [e for e in map_expense_snapshot(expense_snapshot) if e.ownerId == ownerId]

  total_charges = sum(c.amount for c in charges)
  total_expenses = sum(e.amount for e in expenses)

  by_property: dict[str, dict[str, float]] = {}
  for c in charges:
    key = c.propertyId or "unassigned"
    by_property.setdefault(key, {"charges": 0.0, "expenses": 0.0})
    by_property[key]["charges"] += c.amount
  for e in expenses:
    key = e.propertyId or "unassigned"
    by_property.setdefault(key, {"charges": 0.0, "expenses": 0.0})
    by_property[key]["expenses"] += e.amount

  return FinanceSummary(
    ownerId=ownerId,
    totalCharges=total_charges,
    totalExpenses=total_expenses,
    net=total_charges - total_expenses,
    currency="XOF",
    byProperty=by_property,
  )
