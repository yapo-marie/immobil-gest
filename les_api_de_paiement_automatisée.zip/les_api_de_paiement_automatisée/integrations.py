import csv
import io
from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings

router = APIRouter(prefix="/api/integrations", tags=["integrations"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def build_csv(rows: list[dict], fields: list[str]) -> str:
  buffer = io.StringIO()
  writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction="ignore")
  writer.writeheader()
  for row in rows:
    writer.writerow({key: row.get(key, "") for key in fields})
  return buffer.getvalue()


@router.get("/exports/charges")
async def export_charges(
  request: Request,
  ownerId: Optional[str] = None,
  fmt: str = "csv",
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "charges")
  if not isinstance(snapshot, dict):
    snapshot = {}
  rows = []
  for _, value in snapshot.items():
    if ownerId and (value or {}).get("ownerId") != ownerId:
      continue
    rows.append(
      {
        "ownerId": value.get("ownerId"),
        "propertyId": value.get("propertyId"),
        "propertyName": value.get("propertyName"),
        "label": value.get("label"),
        "amount": value.get("amount"),
        "currency": value.get("currency") or "XOF",
        "period": value.get("period"),
        "category": value.get("category"),
        "createdAt": value.get("createdAt"),
      }
    )
  if fmt == "json":
    return rows
  csv_content = build_csv(rows, ["ownerId", "propertyId", "propertyName", "label", "amount", "currency", "period", "category", "createdAt"])
  return Response(content=csv_content, media_type="text/csv")


@router.get("/exports/expenses")
async def export_expenses(
  request: Request,
  ownerId: Optional[str] = None,
  fmt: str = "csv",
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "expenses")
  if not isinstance(snapshot, dict):
    snapshot = {}
  rows = []
  for _, value in snapshot.items():
    if ownerId and (value or {}).get("ownerId") != ownerId:
      continue
    rows.append(
      {
        "ownerId": value.get("ownerId"),
        "propertyId": value.get("propertyId"),
        "propertyName": value.get("propertyName"),
        "vendor": value.get("vendor"),
        "label": value.get("label"),
        "amount": value.get("amount"),
        "currency": value.get("currency") or "XOF",
        "date": value.get("date"),
        "category": value.get("category"),
        "notes": value.get("notes"),
        "createdAt": value.get("createdAt"),
      }
    )
  if fmt == "json":
    return rows
  csv_content = build_csv(rows, ["ownerId", "propertyId", "propertyName", "vendor", "label", "amount", "currency", "date", "category", "notes", "createdAt"])
  return Response(content=csv_content, media_type="text/csv")


@router.get("/exports/paiements")
async def export_payments(
  request: Request,
  ownerId: Optional[str] = None,
  fmt: str = "csv",
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  # reuse Stripe client if configured
  stripe = getattr(request.app.state, "stripe", None)
  if not stripe:
    raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Stripe non configuré.")
  from ..services.payment_service import list_checkout_sessions

  sessions = await list_checkout_sessions(stripe)
  rows = []
  for session in sessions.get("data", []):
    metadata = session.get("metadata") or {}
    if ownerId and metadata.get("ownerId") != ownerId:
      continue
    rows.append(
      {
        "ownerId": metadata.get("ownerId"),
        "tenantId": metadata.get("tenantId"),
        "tenantEmail": metadata.get("tenantEmail"),
        "propertyId": metadata.get("propertyId"),
        "propertyName": metadata.get("propertyName"),
        "amount": (session.get("amount_total") or 0) / 100 if session.get("amount_total") else None,
        "currency": session.get("currency") or "xof",
        "paymentStatus": session.get("payment_status"),
        "createdAt": datetime.utcfromtimestamp(session.get("created")).isoformat() if session.get("created") else None,
      }
    )
  if fmt == "json":
    return rows
  csv_content = build_csv(rows, ["ownerId", "tenantId", "tenantEmail", "propertyId", "propertyName", "amount", "currency", "paymentStatus", "createdAt"])
  return Response(content=csv_content, media_type="text/csv")


@router.get("/bank/stub", response_model=dict)
async def bank_stub():
  """Placeholder agrégation bancaire."""
  return {"status": "not_implemented", "detail": "Connexion bancaire (agrégation PSD2) à brancher."}


@router.get("/syndic/stub", response_model=dict)
async def syndic_stub():
  """Placeholder API syndics/agences."""
  return {"status": "not_implemented", "detail": "API syndic/agence à spécifier."}


@router.get("/caf/stub", response_model=dict)
async def caf_stub():
  """Placeholder CAF APL."""
  return {"status": "not_implemented", "detail": "Connecteur CAF/APL à implémenter selon API disponible."}
