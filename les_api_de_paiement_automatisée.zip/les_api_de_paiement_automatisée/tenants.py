from datetime import datetime
from uuid import uuid4

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.email_utils import send_mail
from ..core.settings import Settings, get_settings
from ..models.tenant import TenantCreate, TenantOut, TenantUpdate

router = APIRouter(prefix="/api/tenants", tags=["tenants"])


def sanitize_tenant_input(payload: TenantCreate, default_owner: str) -> dict:
  if not payload.name.strip():
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Le nom du locataire est requis.")
  return {
    "name": payload.name.strip(),
    "email": payload.email.lower(),
    "phone": payload.phone.strip(),
    "status": payload.status,
    "propertyId": payload.propertyId,
    "ownerId": payload.ownerId or default_owner,
    "note": payload.note.strip() if payload.note else None,
    "entryDate": payload.entryDate,
    "paymentMonths": payload.paymentMonths,
  }


def sanitize_tenant_patch(payload: TenantUpdate) -> dict:
  patch = payload.model_dump(exclude_unset=True)
  patch.pop("id", None)
  if "ownerId" in patch:
    patch.pop("ownerId")
  if "propertyId" in patch:
    patch["propertyId"] = patch["propertyId"] or None
  if "note" in patch and patch["note"] == "":
    patch.pop("note")
  return patch


def map_snapshot(snapshot, default_owner: str):
  if not isinstance(snapshot, dict):
    return []
  results = []
  for tenant_id, raw in snapshot.items():
    record = raw or {}
    results.append(
      {
        "id": tenant_id,
        "name": record.get("name"),
        "email": record.get("email"),
        "phone": record.get("phone"),
        "status": record.get("status") or "pending",
        "propertyId": record.get("propertyId"),
        "ownerId": record.get("ownerId") or default_owner,
        "note": record.get("note"),
        "entryDate": record.get("entryDate"),
        "paymentMonths": record.get("paymentMonths") or 1,
      }
    )
  return results


def map_single(record_id: str, record: dict, default_owner: str) -> dict:
  data = record or {}
  return {
    "id": record_id,
    "name": data.get("name"),
    "email": data.get("email"),
    "phone": data.get("phone"),
    "status": data.get("status") or "pending",
    "propertyId": data.get("propertyId"),
    "ownerId": data.get("ownerId") or default_owner,
    "note": data.get("note"),
    "entryDate": data.get("entryDate"),
    "paymentMonths": data.get("paymentMonths") or 1,
  }


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


async def send_welcome_email(
  client: httpx.AsyncClient,
  settings: Settings,
  *,
  tenant: dict,
) -> None:
  """Envoie un email de bienvenue lors de l'attribution d'un logement."""
  if not settings.mailer_configured:
    return
  recipient = (tenant.get("email") or "").strip()
  if not recipient:
    return

  property_id = tenant.get("propertyId")
  property_name = "votre logement"
  property_address = None
  if property_id:
    try:
      _, property_record = await firebase_request(client, settings, "proprietes", record_id=property_id)
      if isinstance(property_record, dict):
        property_name = property_record.get("name") or property_name
        property_address = property_record.get("address")
    except Exception as exc:  # pragma: no cover - log only
      print(f"[WelcomeEmail] Impossible de récupérer la propriété {property_id}: {exc}")

  subject = f"Bienvenue dans {property_name}"
  lines = [
    f"Bonjour {tenant.get('name') or 'locataire'},",
    "",
    f"Bienvenue dans {property_name}.",
  ]
  if property_address:
    lines.append(f"Adresse : {property_address}")
  lines.extend(
    [
      "Pour toute demande, vous pouvez répondre directement à ce message.",
      "Nous restons disponibles pour faciliter votre installation.",
    ]
  )
  text_body = "\n".join(lines)
  html_body = f"""
  <div style="font-family:Arial,sans-serif;color:#0f172a;line-height:1.6;">
    <h2 style="color:#0ea5e9;margin-bottom:8px;">Bienvenue</h2>
    <p>Bonjour {tenant.get('name') or 'locataire'},</p>
    <p>Bienvenue dans <strong>{property_name}</strong>.</p>
    {f'<p style="color:#475569;font-size:14px;">Adresse : {property_address}</p>' if property_address else ''}
    <p style="color:#475569;font-size:14px;">Pour toute question, vous pouvez répondre directement à ce message.</p>
    <p style="color:#475569;font-size:14px;">Nous restons disponibles pour faciliter votre installation.</p>
  </div>
  """
  try:
    await send_mail(settings, to=recipient, subject=subject, text=text_body, html=html_body)
  except Exception as exc:  # pragma: no cover - log only
    print(f"[WelcomeEmail] Erreur d'envoi: {exc}")
    return

  try:
    await firebase_request(
      client,
      settings,
      "messages",
      method="POST",
      body={
        "tenantId": tenant.get("id"),
        "tenantName": tenant.get("name"),
        "ownerId": tenant.get("ownerId") or settings.default_owner_id,
        "channel": "email",
        "subject": subject,
        "body": text_body,
        "sentAt": datetime.utcnow().isoformat(),
      },
    )
  except Exception as exc:  # pragma: no cover - log only
    print(f"[WelcomeEmail] Erreur de journalisation: {exc}")


@router.get("", response_model=list[TenantOut])
async def list_tenants(
  request: Request,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "locataires")
  return [TenantOut.model_validate(item).model_dump() for item in map_snapshot(snapshot, settings.default_owner_id)]


@router.post("", response_model=TenantOut, status_code=status.HTTP_201_CREATED)
async def create_tenant(
  request: Request,
  payload: TenantCreate,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  body = sanitize_tenant_input(payload, settings.default_owner_id)
  status_code, snapshot = await firebase_request(client, settings, "locataires", method="POST", body=body)
  tenant_id = snapshot.get("name") if isinstance(snapshot, dict) else str(uuid4())

  # Automatically mark property as occupied
  if body.get("propertyId"):
    await firebase_request(
      client,
      settings,
      "proprietes",
      method="PATCH",
      record_id=body["propertyId"],
      body={"status": "occupied"},
    )

  tenant_record = {**body, "id": tenant_id}

  # Envoi automatique du message de bienvenue si un logement est attribué
  if body.get("propertyId"):
    await send_welcome_email(
      client,
      settings,
      tenant=tenant_record,
    )

  return TenantOut.model_validate(tenant_record).model_dump()


@router.patch("/{tenant_id}", response_model=TenantOut)
async def update_tenant(
  tenant_id: str,
  payload: TenantUpdate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  patch = sanitize_tenant_patch(payload)
  # Récupérer l'enregistrement actuel pour retourner un payload complet
  _, existing = await firebase_request(client, settings, "locataires", record_id=tenant_id)
  if existing is None:
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Locataire introuvable.")
  
  # Handle property change if needed (optional complexity, skipping for now to keep it simple or add if requested)
  # Ideally: if propertyId changes, mark old as vacant and new as occupied. 
  # For now, let's just update the tenant.

  await firebase_request(client, settings, "locataires", method="PATCH", record_id=tenant_id, body=patch)
  merged = map_single(tenant_id, existing, settings.default_owner_id) | patch

  # Envoi du message de bienvenue si un logement vient d'être attribué
  previous_property = existing.get("propertyId")
  new_property = merged.get("propertyId")
  if new_property and new_property != previous_property:
    await send_welcome_email(
      client,
      settings,
      tenant=merged,
    )

  return TenantOut.model_validate(merged).model_dump()


@router.delete("/{tenant_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_tenant(
  tenant_id: str,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  # Fetch tenant to find propertyId
  _, existing = await firebase_request(client, settings, "locataires", record_id=tenant_id)
  
  await firebase_request(client, settings, "locataires", method="DELETE", record_id=tenant_id)

  # Automatically mark property as vacant if it was assigned
  if existing and existing.get("propertyId"):
    await firebase_request(
      client,
      settings,
      "proprietes",
      method="PATCH",
      record_id=existing["propertyId"],
      body={"status": "vacant"},
    )
