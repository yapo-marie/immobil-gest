from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.automation import IRLRequest, RegularizationRequest
from ..services.automation_service import apply_irl_indexation, log_alerts, regularize_charges

router = APIRouter(prefix="/api/automation", tags=["automation"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


@router.post("/irl", response_model=dict)
async def run_irl(
  payload: IRLRequest,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if payload.rate == 0:
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Taux IRL requis (ex: 0.02).")
  owner_id = payload.ownerId or settings.default_owner_id
  client = get_client(request)
  result = await apply_irl_indexation(client, settings, owner_id, payload.rate)
  log_entry = {
    "type": "irl",
    "ownerId": owner_id,
    "detail": f"Indexation IRL {payload.rate * 100:.2f}% sur {result.get('updated')} biens",
    "createdAt": datetime.utcnow().isoformat(),
  }
  await firebase_request(client, settings, "automationLogs", method="POST", body=log_entry)
  return {"status": "ok", "updated": result.get("updated", 0)}


@router.post("/regularisation", response_model=dict)
async def run_regularisation(
  payload: RegularizationRequest,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if payload.rate == 0:
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Taux de regularisation requis (ex: 0.05).")
  owner_id = payload.ownerId or settings.default_owner_id
  client = get_client(request)
  result = await regularize_charges(client, settings, owner_id, payload.rate, payload.label)
  log_entry = {
    "type": "regularisation",
    "ownerId": owner_id,
    "detail": f"Regularisation {payload.rate * 100:.2f}% creee pour {result.get('created')} biens",
    "createdAt": datetime.utcnow().isoformat(),
  }
  await firebase_request(client, settings, "automationLogs", method="POST", body=log_entry)
  return {"status": "ok", "created": result.get("created", 0)}


@router.post("/alerts", response_model=dict)
async def run_alerts(
  ownerId: Optional[str] = None,
  request: Request = None,
  settings: Settings = Depends(get_settings),
):
  owner = ownerId or settings.default_owner_id
  client = get_client(request)
  result = await log_alerts(client, settings, owner)
  return {"status": "ok", **result}
