from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.maintenance import TicketCreate, TicketRecord, TicketUpdate, VendorCreate, VendorRecord, WorkLogCreate, WorkLogRecord

router = APIRouter(prefix="/api/maintenance", tags=["maintenance"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def map_records(snapshot: Optional[dict], model):
  if not isinstance(snapshot, dict):
    return []
  results = []
  for record_id, raw in snapshot.items():
    data = raw or {}
    try:
      results.append(model(id=record_id, **data))
    except Exception:
      continue
  return results


@router.post("/vendors", response_model=VendorRecord, status_code=status.HTTP_201_CREATED)
async def create_vendor(
  payload: VendorCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "vendors", method="POST", body=body)
  vendor_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return VendorRecord.model_validate({**body, "id": vendor_id})


@router.get("/vendors", response_model=list[VendorRecord])
async def list_vendors(
  request: Request,
  ownerId: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "vendors")
  vendors = map_records(snapshot, VendorRecord)
  if ownerId:
    vendors = [v for v in vendors if v.ownerId == ownerId]
  vendors.sort(key=lambda v: v.createdAt, reverse=True)
  return vendors


@router.post("/tickets", response_model=TicketRecord, status_code=status.HTTP_201_CREATED)
async def create_ticket(
  payload: TicketCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if not payload.title.strip() or not payload.description.strip():
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Titre et description requis.")
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "tickets", method="POST", body=body)
  ticket_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return TicketRecord.model_validate({**body, "id": ticket_id})


@router.get("/tickets", response_model=list[TicketRecord])
async def list_tickets(
  request: Request,
  ownerId: Optional[str] = None,
  propertyId: Optional[str] = None,
  status: Optional[str] = None,
  tenantId: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "tickets")
  tickets = map_records(snapshot, TicketRecord)
  if ownerId:
    tickets = [t for t in tickets if t.ownerId == ownerId]
  if propertyId:
    tickets = [t for t in tickets if t.propertyId == propertyId]
  if status:
    tickets = [t for t in tickets if t.status == status]
  if tenantId:
    tickets = [t for t in tickets if t.tenantId == tenantId]
  tickets.sort(key=lambda t: t.createdAt, reverse=True)
  return tickets


@router.patch("/tickets/{ticket_id}", response_model=TicketRecord)
async def update_ticket(
  ticket_id: str,
  payload: TicketUpdate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  patch = payload.model_dump(exclude_unset=True)
  patch.pop("id", None)
  client = get_client(request)
  _, existing = await firebase_request(client, settings, "tickets", record_id=ticket_id)
  if existing is None:
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket introuvable.")
  await firebase_request(client, settings, "tickets", method="PATCH", record_id=ticket_id, body=patch)
  merged = {**(existing or {}), **patch, "id": ticket_id}
  return TicketRecord.model_validate(merged)


@router.post("/logs", response_model=WorkLogRecord, status_code=status.HTTP_201_CREATED)
async def create_worklog(
  payload: WorkLogCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if not payload.note.strip():
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Note requise.")
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "workLogs", method="POST", body=body)
  log_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return WorkLogRecord.model_validate({**body, "id": log_id})


@router.get("/logs", response_model=list[WorkLogRecord])
async def list_worklogs(
  request: Request,
  ownerId: Optional[str] = None,
  ticketId: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "workLogs")
  logs = map_records(snapshot, WorkLogRecord)
  if ownerId:
    logs = [l for l in logs if l.ownerId == ownerId]
  if ticketId:
    logs = [l for l in logs if l.ticketId == ticketId]
  logs.sort(key=lambda l: l.createdAt, reverse=True)
  return logs
