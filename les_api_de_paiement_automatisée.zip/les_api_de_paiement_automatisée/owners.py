from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.owner import OwnerCreate, OwnerRecord

router = APIRouter(prefix="/api/owners", tags=["owners"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def map_records(snapshot: Optional[dict]) -> list[OwnerRecord]:
  if not isinstance(snapshot, dict):
    return []
  results = []
  for owner_id, raw in snapshot.items():
    data = raw or {}
    try:
      results.append(OwnerRecord(id=owner_id, **data))
    except Exception:
      continue
  return results


@router.post("", response_model=OwnerRecord, status_code=status.HTTP_201_CREATED)
async def create_owner(
  payload: OwnerCreate,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  if not payload.name.strip() or not payload.email.strip():
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Nom et email requis.")
  body = payload.model_dump()
  body["createdAt"] = datetime.utcnow().isoformat()
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "owners", method="POST", body=body)
  owner_id = snapshot.get("name") if isinstance(snapshot, dict) else ""
  return OwnerRecord.model_validate({**body, "id": owner_id})


@router.get("", response_model=list[OwnerRecord])
async def list_owners(
  request: Request,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "owners")
  owners = map_records(snapshot)
  owners.sort(key=lambda o: o.createdAt, reverse=True)
  return owners


@router.get("/summary", response_model=dict)
async def owner_summary(
  request: Request,
  ownerId: str,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, tenants_snapshot = await firebase_request(client, settings, "locataires")
  _, properties_snapshot = await firebase_request(client, settings, "proprietes")
  _, charges_snapshot = await firebase_request(client, settings, "charges")
  _, expenses_snapshot = await firebase_request(client, settings, "expenses")

  tenants = (tenants_snapshot or {}) if isinstance(tenants_snapshot, dict) else {}
  properties = (properties_snapshot or {}) if isinstance(properties_snapshot, dict) else {}
  charges = (charges_snapshot or {}) if isinstance(charges_snapshot, dict) else {}
  expenses = (expenses_snapshot or {}) if isinstance(expenses_snapshot, dict) else {}

  owned_properties = [p for p in properties.values() if (p or {}).get("ownerId", settings.default_owner_id) == ownerId]
  occupied = [p for p in owned_properties if (p or {}).get("status") == "occupied"]
  vacancy_rate = 0.0
  if owned_properties:
    vacancy_rate = max(0.0, (len(owned_properties) - len(occupied)) / len(owned_properties))

  total_rent = sum(float((p or {}).get("rent") or 0) for p in owned_properties)
  total_charges = sum(float((c or {}).get("amount") or 0) for c in charges.values() if (c or {}).get("ownerId") == ownerId)
  total_expenses = sum(float((e or {}).get("amount") or 0) for e in expenses.values() if (e or {}).get("ownerId") == ownerId)

  return {
    "ownerId": ownerId,
    "properties": len(owned_properties),
    "occupied": len(occupied),
    "vacancyRate": vacancy_rate,
    "monthlyRent": total_rent,
    "charges": total_charges,
    "expenses": total_expenses,
    "net": total_rent - total_charges - total_expenses,
  }
