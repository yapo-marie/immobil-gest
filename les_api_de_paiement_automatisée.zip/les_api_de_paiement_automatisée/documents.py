import base64
from datetime import datetime
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fpdf import FPDF

from ..core.firebase import firebase_request
from ..core.settings import Settings, get_settings
from ..models.document import DocumentRecord, QuittanceRequest

router = APIRouter(prefix="/api/documents", tags=["documents"])


def get_client(request: Request) -> httpx.AsyncClient:
  return request.app.state.http_client


def build_quittance_pdf(payload: QuittanceRequest) -> bytes:
  pdf = FPDF(orientation="P", unit="mm", format="A4")
  pdf.add_page()
  pdf.set_auto_page_break(auto=True, margin=15)

  pdf.set_font("Arial", "B", 16)
  pdf.cell(0, 10, "Quittance de loyer", ln=1, align="C")

  pdf.set_font("Arial", size=11)
  pdf.cell(0, 8, f"Locataire : {payload.tenantName}", ln=1)
  if payload.propertyName:
    pdf.cell(0, 8, f"Logement : {payload.propertyName}", ln=1)
  if payload.period:
    pdf.cell(0, 8, f"Periode : {payload.period}", ln=1)
  pdf.cell(0, 8, f"Montant : {payload.amount} {payload.currency.upper()}", ln=1)
  if payload.paidAt:
    pdf.cell(0, 8, f"Payé le : {payload.paidAt}", ln=1)
  issue_date = payload.issueDate or datetime.utcnow().date().isoformat()
  pdf.cell(0, 8, f"Emise le : {issue_date}", ln=1)

  pdf.ln(10)
  pdf.multi_cell(
    0,
    8,
    "Certifie avoir reçu les sommes dues au titre du loyer et des charges pour la période indiquée ci-dessus.",
  )
  pdf.ln(10)
  pdf.cell(0, 8, "Signature :", ln=1)

  return pdf.output(dest="S").encode("latin1")


def map_snapshot(snapshot: Optional[dict]) -> list[DocumentRecord]:
  if not isinstance(snapshot, dict):
    return []
  results: list[DocumentRecord] = []
  for doc_id, raw in snapshot.items():
    record = raw or {}
    try:
      results.append(
        DocumentRecord(
          id=doc_id,
          type=record.get("type") or "document",
          title=record.get("title") or "Document",
          ownerId=record.get("ownerId"),
          tenantId=record.get("tenantId"),
          tenantName=record.get("tenantName"),
          propertyId=record.get("propertyId"),
          propertyName=record.get("propertyName"),
          amount=float(record.get("amount")) if record.get("amount") is not None else None,
          currency=record.get("currency") or "XOF",
          period=record.get("period"),
          version=int(record.get("version") or 1),
          fileName=record.get("fileName"),
          archivedAt=record.get("archivedAt"),
          createdAt=record.get("createdAt") or "",
        )
      )
    except Exception:
      continue
  return results


@router.get("", response_model=list[DocumentRecord])
async def list_documents(
  request: Request,
  ownerId: Optional[str] = None,
  docType: Optional[str] = None,
  tenantId: Optional[str] = None,
  propertyId: Optional[str] = None,
  settings: Settings = Depends(get_settings),
):
  client = get_client(request)
  _, snapshot = await firebase_request(client, settings, "documents")
  docs = map_snapshot(snapshot)
  if ownerId:
    docs = [doc for doc in docs if doc.ownerId == ownerId]
  if docType:
    docs = [doc for doc in docs if doc.type == docType]
  if tenantId:
    docs = [doc for doc in docs if doc.tenantId == tenantId]
  if propertyId:
    docs = [doc for doc in docs if doc.propertyId == propertyId]
  docs.sort(key=lambda d: d.createdAt, reverse=True)
  return docs


@router.post("/quittance", response_model=dict)
async def generate_quittance(
  payload: QuittanceRequest,
  request: Request,
  settings: Settings = Depends(get_settings),
):
  owner_id = payload.ownerId or settings.default_owner_id
  pdf_bytes = build_quittance_pdf(payload)
  base64_pdf = base64.b64encode(pdf_bytes).decode("ascii")
  client = get_client(request)

  doc_body = {
    "type": "quittance",
    "title": f"Quittance {payload.period}",
    "ownerId": owner_id,
    "tenantId": payload.tenantId,
    "tenantName": payload.tenantName,
    "propertyId": payload.propertyId,
    "propertyName": payload.propertyName,
    "amount": payload.amount,
    "currency": payload.currency or "XOF",
    "period": payload.period,
    "version": 1,
    "fileName": f"quittance-{payload.period.replace(' ', '_')}.pdf",
    "createdAt": datetime.utcnow().isoformat(),
  }

  try:
    _, snapshot = await firebase_request(client, settings, "documents", method="POST", body=doc_body)
    doc_id = snapshot.get("name") if isinstance(snapshot, dict) else None
  except Exception:
    doc_id = None

  return {
    "documentId": doc_id,
    "fileName": doc_body["fileName"],
    "contentType": "application/pdf",
    "base64": base64_pdf,
    "metadata": {**doc_body, "id": doc_id},
  }
